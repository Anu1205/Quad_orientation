from django.db import models

# Create your models here.

class content(models.Model):
    info=models.TextField()
class phnum(models.Model):
    number=models.CharField(max_length=19)
    def __int__():
    	return self.number
