
from rest_framework import serializers
from .models import content
from .models import phnum

class contentSerializer(serializers.ModelSerializer):
    #info=serializers.TextField()

    class Meta:
        model = content
        fields = ('info')
        
class phnumSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = phnum
        fields = ('number')
