from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from text import views

urlpatterns = [
    path('numbers/', views.numbers),
]
