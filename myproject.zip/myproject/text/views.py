from django.shortcuts import render
import re
from django.http import HttpResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from text.models import phnum
from text.models import content
from text.serializers import contentSerializer
from text.serializers import phnumSerializer



@api_view(['GET'])
def numbers(request):
   if request.method == 'GET':
      con=content.object.all()
      reg=r"(\d{4})"
      for i in con:
           phnumbers= re.search(reg,i)
      #phnumbers = phnum.objects.all()
      serializer = phnumSerializer(phnumbers, many=True)
   return Response(serializer.data)






